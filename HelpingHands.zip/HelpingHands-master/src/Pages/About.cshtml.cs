using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ContosoCrafts.WebSite.Pages
{

    /// <summary>
    /// Class for AboutModel
    /// </summary>
    public class AboutModel : PageModel
    {

    }
}