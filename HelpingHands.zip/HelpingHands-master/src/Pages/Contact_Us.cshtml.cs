using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace ContosoCrafts.WebSite.Pages
{

    /// <summary>
    /// Class for Contact_Us Model
    /// </summary>
    public class Contact_UsModel : PageModel
    {

    }
}