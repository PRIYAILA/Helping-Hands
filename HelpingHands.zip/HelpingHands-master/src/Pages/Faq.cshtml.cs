﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace ContosoCrafts.WebSite.Pages
{

    /// <summary>
    /// Class to handle operations related to Faq page
    /// </summary>
    public class FaqModel : PageModel
    {
       
    }
}