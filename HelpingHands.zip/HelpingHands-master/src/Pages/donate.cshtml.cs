using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ContosoCrafts.WebSite.Pages
{

    /// <summary>
    /// Class for donateModel
    /// </summary>
    public class donateModel : PageModel
    {

    }
}